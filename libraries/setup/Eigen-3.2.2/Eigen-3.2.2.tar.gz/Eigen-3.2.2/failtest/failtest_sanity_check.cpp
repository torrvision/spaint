#ifdef EIGEN_SHOULD_FAIL_TO_BUILD
This is just some text that won't compile as a C++ file, as a basic sanity check for failtest.
#else
int main() {}
#endif
