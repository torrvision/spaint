/*******************************************************
 * Copyright (c) 2014, ArrayFire
 * All rights reserved.
 *
 * This file is distributed under 3-clause BSD license.
 * The complete license agreement can be obtained at:
 * http://arrayfire.com/licenses/BSD-3-Clause
 ********************************************************/

#include <err_common.hpp>

#define CPU_NOT_SUPPORTED() do {                       \
        throw SupportError(__FILE__, __LINE__, "CPU"); \
    } while(0)
